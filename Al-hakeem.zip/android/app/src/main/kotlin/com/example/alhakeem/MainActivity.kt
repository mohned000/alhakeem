package com.example.alhakeem

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
