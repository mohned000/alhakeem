buildscript {

    val kotlin_version by extra("2.1.20")

    repositories {

        google()

        mavenCentral()

    }

    dependencies {

        classpath("com.android.tools.build:gradle:8.1.0")

        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version")

        classpath("com.google.gms:google-services:4.4.2")

    }

}

allprojects {

    repositories {

        google()

        mavenCentral()

    }

}