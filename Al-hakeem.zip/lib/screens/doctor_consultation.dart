import 'package:flutter/material.dart';

class DoctorConsultationScreen extends StatelessWidget {

  @override

  Widget build(BuildContext context) {

    return Scaffold(

      appBar: AppBar(title: Text('استشارة طبيب')),

      body: Center(

        child: Column(

          mainAxisAlignment: MainAxisAlignment.center,

          children: [

            Text('أسماء الأطباء المتاحين للاستشارة:'),

            Text('الدكتور أحمد - تخصص جراحة عامة'),

            Text('الدكتور محمد - تخصص قلب'),

            ElevatedButton(

              onPressed: () {

                // الاتصال عبر واتساب

              },

              child: Text('التواصل مع الطبيب عبر واتساب'),

            ),

          ],

        ),

      ),

    );

  }

}