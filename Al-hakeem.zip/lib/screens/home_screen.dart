import 'package:flutter/material.dart';

import 'package:firebase_auth/firebase_auth.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

import 'ambulance_screen.dart'; // صفحة طلب سيارة الإسعاف

import 'doctor_consultation.dart'; // صفحة استشارة الطبيب

import 'lab_test_screen.dart'; // صفحة فحص عينة

import 'medicine_search_screen.dart'; // صفحة البحث عن دواء

import 'appointments_screen.dart'; // صفحة حجز مواعيد العيادات

import 'nurse_request_screen.dart'; // صفحة طلب ممرض

import 'physical_therapy_screen.dart'; // صفحة طلب معالج طبيعي

import 'ct_mri_screen.dart'; // صفحة أماكن توفر CT و MRI

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('خدمات طبية')),
      body: Column(
        children: [
          // مربع النشرات الطبية

          StreamBuilder(
            stream: FirebaseFirestore.instance
                .collection('medical_bulletins')
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return CircularProgressIndicator();
              }

              final bulletin = snapshot.data!.docs.last['bulletin'];

              return Container(
                padding: EdgeInsets.all(10),
                color: Colors.blue,
                child: Text(bulletin, style: TextStyle(color: Colors.white)),
              );
            },
          ),

          // أيقونات الخدمات الطبية

          GridView.builder(
            shrinkWrap: true,
            itemCount: 8,
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
            ),
            itemBuilder: (context, index) {
              return IconButton(
                icon: Icon(Icons.medical_services),
                onPressed: () {
                  switch (index) {
                    case 0:
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => AmbulanceScreen()));

                      break;

                    case 1:
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => DoctorConsultationScreen()));

                      break;

                    case 2:
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => LabTestScreen()));

                      break;

                    case 3:
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => MedicineSearchScreen()));

                      break;

                    case 4:
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => AppointmentsScreen()));

                      break;

                    case 5:
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => NurseRequestScreen()));

                      break;

                    case 6:
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => PhysicalTherapyScreen()));

                      break;

                    case 7:
                      Navigator.push(context,
                          MaterialPageRoute(builder: (_) => CtMriScreen()));

                      break;
                  }
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
